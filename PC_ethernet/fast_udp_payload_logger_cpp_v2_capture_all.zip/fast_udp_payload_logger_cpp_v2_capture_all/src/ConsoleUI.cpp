#include "ConsoleUI.hpp"
#include "NpcapLogger.hpp"
#include "Utils.hpp"

#include <iostream>
#include <stdexcept>
#include <string>

static std::string ask_string(const std::string& prompt, const std::string& current) {
    std::cout << prompt << " [" << (current.empty() ? "disabled/empty" : current) << "]: ";
    std::string line;
    std::getline(std::cin, line);
    line = trim(line);
    return line.empty() ? current : line;
}

static uint16_t ask_u16(const std::string& prompt, uint16_t current) {
    std::cout << prompt << " [" << current << ", 0=disabled]: ";
    std::string line;
    std::getline(std::cin, line);
    line = trim(line);
    return line.empty() ? current : parse_u16(line);
}

static uint64_t ask_u64(const std::string& prompt, uint64_t current) {
    std::cout << prompt << " [" << current << ", 0=unlimited/disabled]: ";
    std::string line;
    std::getline(std::cin, line);
    line = trim(line);
    return line.empty() ? current : parse_u64(line);
}

static int ask_int(const std::string& prompt, int current) {
    std::cout << prompt << " [" << current << "]: ";
    std::string line;
    std::getline(std::cin, line);
    line = trim(line);
    return line.empty() ? current : std::stoi(line);
}

static bool ask_bool(const std::string& prompt, bool current) {
    std::cout << prompt << " [" << (current ? "true" : "false") << "]: ";
    std::string line;
    std::getline(std::cin, line);
    line = trim(line);
    return line.empty() ? current : parse_bool(line);
}

int run_console_ui(LoggerConfig& cfg) {
    std::cout << "=============================================\n";
    std::cout << " Fast UDP Payload Logger v2 - C++ / Npcap\n";
    std::cout << "=============================================\n\n";

    std::cout << "Output modes:\n";
    std::cout << "  1 = raw binary payload bytes, fastest\n";
    std::cout << "  2 = hex TXT, one saved payload per line\n";
    std::cout << "  3 = decoded 24-bit LSB CSV\n\n";

    int mode = ask_int("Choose output mode", static_cast<int>(cfg.output_mode));
    if (mode < 1 || mode > 3) throw std::runtime_error("Invalid output mode");
    cfg.output_mode = static_cast<OutputMode>(mode);

    std::cout << "\nPayload length modes:\n";
    std::cout << "  1 = strict UDP length, normal/correct networking\n";
    std::cout << "  2 = save everything after UDP header until end of captured Ethernet frame\n";
    std::cout << "  3 = save everything after UDP header until end of IP packet\n\n";

    int len_mode = ask_int("Choose payload length mode", static_cast<int>(cfg.payload_length_mode));
    if (len_mode < 1 || len_mode > 3) throw std::runtime_error("Invalid payload length mode");
    cfg.payload_length_mode = static_cast<PayloadLengthMode>(len_mode);

    if (cfg.output_mode == OutputMode::RawBinary) cfg.output_file = "output/payload.bin";
    else if (cfg.output_mode == OutputMode::HexText) cfg.output_file = "output/payload_hex.txt";
    else cfg.output_file = "output/samples_24bit.csv";

    cfg.output_file = ask_string("Output file", cfg.output_file);

    std::cout << "\nPacket filters. Empty MAC/IP disables that filter. Port 0 disables port filter.\n";
    cfg.expected_dst_mac = ask_string("Expected destination MAC", cfg.expected_dst_mac);
    cfg.expected_src_mac = ask_string("Expected source MAC", cfg.expected_src_mac);
    cfg.expected_src_ip = ask_string("Expected source IP", cfg.expected_src_ip);
    cfg.expected_dst_ip = ask_string("Expected destination IP", cfg.expected_dst_ip);
    cfg.expected_udp_src_port = ask_u16("Expected UDP source port", cfg.expected_udp_src_port);
    cfg.expected_udp_dst_port = ask_u16("Expected UDP destination port", cfg.expected_udp_dst_port);

    if (cfg.output_mode == OutputMode::Decoded24Csv) {
        std::cout << "\n24-bit CSV decode settings:\n";
        cfg.signed_24bit = ask_bool("Signed 24-bit?", cfg.signed_24bit);
        cfg.num_channels = ask_int("Number of channels", cfg.num_channels);
    }

    std::cout << "\nStop/performance settings:\n";
    cfg.max_matching_packets = ask_u64("Max matching packets", cfg.max_matching_packets);
    cfg.max_payload_bytes = ask_u64("Max saved payload bytes", cfg.max_payload_bytes);
    cfg.flush_every_packets = ask_u64("Flush every N packets", cfg.flush_every_packets);
    cfg.verbose = ask_bool("Verbose stats?", cfg.verbose);

    std::cout << "\nAvailable Npcap adapters:\n";
    auto adapters = list_adapters();

    for (const auto& a : adapters) {
        std::cout << "  " << a.index << ": " << a.description << "\n";
        std::cout << "      " << a.name << "\n";
    }

    int adapter_index = ask_int("\nChoose adapter number", 1);
    return adapter_index;
}
